```markdown
# Bot Telegram - Sinais (IA) (DEMO)

Este repositório contém um bot Telegram simples que demonstra geração de sinais usando um modelo de RandomForest treinado com dados simulados (DEMO).

Aviso: O código usa dados simulados para demonstração. Ajuste a lógica, modelo e tratamento conforme necessário antes de usar em produção.

## Arquivos
- `bot.py` - código principal do bot.
- `requirements.txt` - dependências Python.
- `.gitignore` - arquivos ignorados.
- `LICENSE` - (opcional, adicione se desejar).

## Configuração
1. Instale dependências:
```bash
pip install -r requirements.txt
```

2. Configure `bot.py`:
- Substitua `TOKEN = "SEU_TOKEN_AQUI"` pelo token do seu bot Telegram (recomendo usar variável de ambiente).
- Atualize `CANAL_VIP`, `ADMIN_ID`, `INTERVALO_MINUTOS` conforme necessário.

3. Execute:
```bash
python bot.py
```

## Observações
- O modelo é treinado com dados aleatórios para demonstração (`gerar_dados`). Troque pelo seu dataset real para previsões relevantes.
- Tenha cuidado ao usar bots para sinais de apostas; verifique conformidade legal e termos de uso.
```